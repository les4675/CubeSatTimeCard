#include <msp430.h>

// Global variables for timer overflow and capture timestamps
volatile unsigned long timer_overflow_count = 0;
volatile unsigned long pps1_timestamp = 0; // GNSS PPS timestamp from P2.1 interrupt
volatile unsigned long pps2_timestamp = 0; // CSAC PPS timestamp from P2.0 interrupt
volatile unsigned char pps1_captured = 0;
volatile unsigned char pps2_captured = 0;
volatile unsigned long diff = 0;

// UART function prototypes
void uart_init(void);
void uart_send_char(char c);
void uart_send_string(const char *str);
void utoa(unsigned long value, char *str);

int main(void) {
    char buf[12];

    WDTCTL = WDTPW | WDTHOLD;   // Stop watchdog timer

    uart_init();

    // Set up Timer_A as a free-running counter in continuous mode using SMCLK,
    // and enable its overflow interrupt to extend the 16-bit counter.
    TACTL = TASSEL_2 | MC_2 | TAIE;

    // Configure CSAC PPS on P2.0 (external interrupt)
    P2DIR &= ~BIT0;      // Input
    P2IE  |= BIT0;       // Enable interrupt on P2.0
    P2IES &= ~BIT0;      // Trigger on rising edge
    P2IFG &= ~BIT0;      // Clear flag

    // Configure GNSS PPS on P2.1 (external interrupt)
    P2DIR &= ~BIT1;      // Input
    P2IE  |= BIT1;       // Enable interrupt on P2.1
    P2IES &= ~BIT1;      // Trigger on rising edge
    P2IFG &= ~BIT1;      // Clear flag

    __enable_interrupt();   // Enable global interrupts

    while (1) {
        if (pps1_captured && pps2_captured) {
            // Compute the absolute phase difference in timer counts.
            if (pps1_timestamp > pps2_timestamp)
                diff = pps1_timestamp - pps2_timestamp;
            else
                diff = pps2_timestamp - pps1_timestamp;

            uart_send_string("Phase diff: ");
            utoa(diff, buf);
            uart_send_string(buf);
            uart_send_string("\r\n");

            // Reset flags for the next measurement.
            pps1_captured = 0;
            pps2_captured = 0;
        }
    }
}

// UART initialization for 9600 baud using SMCLK (~1MHz)
void uart_init(void) {
    // Configure UART pins: P1.1 (RX) and P1.2 (TX)
    P1SEL  |= BIT1 | BIT2;
    P1SEL2 |= BIT1 | BIT2;

    UCA0CTL1 |= UCSWRST;       // Put state machine in reset
    UCA0CTL1 |= UCSSEL_2;      // Use SMCLK

    // Baud rate configuration for 9600 baud (1MHz/9600 = 104)
    UCA0BR0 = 104;
    UCA0BR1 = 0;
    UCA0MCTL = UCBRS0;

    UCA0CTL1 &= ~UCSWRST;      // Release state machine
}

// Transmit a single character over UART
void uart_send_char(char c) {
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = c;
}

// Transmit a null-terminated string over UART
void uart_send_string(const char *str) {
    while (*str)
        uart_send_char(*str++);
}

// Convert an unsigned long integer to a decimal string
void utoa(unsigned long value, char *str) {
    char buf[12];
    int i = 0;
    int j = 0;
    if (value == 0) {
        str[0] = '0';
        str[1] = '\0';
        return;
    }
    while (value > 0 && i < 11) {
        buf[i++] = '0' + (value % 10);
        value /= 10;
    }
    // Reverse the string.
    for (j = 0; j < i; j++)
        str[j] = buf[i - 1 - j];
    str[i] = '\0';
}

// Timer_A ISR to handle timer overflow (extending the 16-bit counter)
#pragma vector = TIMER0_A1_VECTOR
__interrupt void Timer_A_ISR(void) {
    switch (__even_in_range(TA0IV,10)) {
        case 10:  // Overflow
            timer_overflow_count++;
            break;
        default:
            break;
    }
}

// Port 2 ISR handles both P2.0 and P2.1 interrupts.
#pragma vector = PORT2_VECTOR
__interrupt void Port_2_ISR(void) {
    // CSAC PPS on P2.0
    if (P2IFG & BIT0) {
        pps2_timestamp = (((unsigned long)timer_overflow_count) << 16) | TA0R;
        pps2_captured = 1;
        P2IFG &= ~BIT0; // Clear flag for P2.0
    }
    // GNSS PPS on P2.1
    if (P2IFG & BIT1) {
        pps1_timestamp = (((unsigned long)timer_overflow_count) << 16) | TA0R;
        pps1_captured = 1;
        P2IFG &= ~BIT1; // Clear flag for P2.1
    }
}
